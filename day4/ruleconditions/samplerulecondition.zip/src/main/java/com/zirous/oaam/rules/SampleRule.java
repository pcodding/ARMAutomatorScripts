package com.zirous.oaam.rules;

import org.apache.log4j.Logger;

import com.bharosa.vcrypt.tracker.rules.intf.VCryptTrackerDevice;
import com.bharosa.vcrypt.tracker.rules.intf.VCryptTrackerLocation;
import com.bharosa.vcrypt.tracker.rules.intf.VCryptTrackerSession;
import com.bharosa.vcrypt.tracker.rules.intf.VCryptTrackerUser;

/** A Sample rule illustrating how to execute
 * @author oracle
 * 
 */
public class SampleRule {
	private static Logger logger = Logger.getLogger(SampleRule.class);

	public static Boolean runRuleLogic(VCryptTrackerSession trackerSession, String signOnType) {

		VCryptTrackerUser user = trackerSession.getVCryptTrackerUser();
		VCryptTrackerLocation location = trackerSession.getVCryptTrackerLocation();
		VCryptTrackerDevice device = trackerSession.getVCryptTrackerDevice();

		//Get info about the user from OAAM
		String loginId = user.getLoginId();
		String externalUserId = user.getUserId();
		
		//Get information about the location used
		String ipAddress = location.getIPAddress();

		// Lookup information about user in external source and perform check
		
		if (logger.isDebugEnabled())
			logger.debug("Processing rule for user: " + loginId
					+ " with IP Address: " + ipAddress + " with signOnType: "
					+ signOnType);
		
		return true;
	}
}
